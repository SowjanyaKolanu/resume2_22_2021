package uk.tw.energy.domain;

import java.math.BigDecimal;

public class PlanConsumptionCost {

	
	String PlanName;
	BigDecimal Cost;
	public String getPlanName() {
		return PlanName;
	}
	public void setPlanName(String planName) {
		PlanName = planName;
	}
	public BigDecimal getCost() {
		return Cost;
	}
	public void setCost(BigDecimal cost) {
		Cost = cost;
	}
	
	
}
