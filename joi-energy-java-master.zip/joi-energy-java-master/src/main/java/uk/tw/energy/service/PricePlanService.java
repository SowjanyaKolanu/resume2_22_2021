package uk.tw.energy.service;

import org.springframework.stereotype.Service;
import uk.tw.energy.domain.ElectricityReading;
import uk.tw.energy.domain.PlanConsumptionCost;
import uk.tw.energy.domain.PricePlan;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class PricePlanService {

    private final List<PricePlan> pricePlans;
    private final MeterReadingService meterReadingService;

    public PricePlanService(List<PricePlan> pricePlans, MeterReadingService meterReadingService) {
        this.pricePlans = pricePlans;
        this.meterReadingService = meterReadingService;
    }

    public Optional<List<PlanConsumptionCost>> getConsumptionCostOfElectricityReadingsForEachPricePlan(String smartMeterId) {
        Optional<List<ElectricityReading>> electricityReadings = meterReadingService.getReadings(smartMeterId);
        
       
        System.out.println("Readings for "+smartMeterId+" "+electricityReadings.get());
        for(int i=0;i<electricityReadings.get().size();i++) {
        	System.out.println("Readings "+i+" "+electricityReadings.get().get(i).getReading()+ " Time "+electricityReadings.get().get(1).getTime());
        }
        if (!electricityReadings.isPresent()) {
            return Optional.empty();
        }
        
        // Changed code ----------------------------------------
        //List of cost for Each plan
        List<PlanConsumptionCost> costForEachPlan = new ArrayList<PlanConsumptionCost>();
       
        //Get cost for each Plan
        for(int i=0;i<pricePlans.size();i++) {
        	PlanConsumptionCost p = new PlanConsumptionCost();
            p.setPlanName(pricePlans.get(i).getPlanName());
            p.setCost(calculateCost(electricityReadings.get(),pricePlans.get(i)));
            costForEachPlan.add(p);
        }
        System.out.println(Optional.ofNullable(costForEachPlan));
		return Optional.ofNullable(costForEachPlan);
        //----------------------------------------------------------
        
        /*return Optional.of(pricePlans.stream().collect(
                Collectors.toMap(PricePlan::getPlanName, t -> calculateCost(electricityReadings.get(), t))));*/
    }

    private BigDecimal calculateCost(List<ElectricityReading> electricityReadings, PricePlan pricePlan) {
        BigDecimal average = calculateAverageReading(electricityReadings);
        BigDecimal timeElapsed = calculateTimeElapsed(electricityReadings);

        BigDecimal averagedCost = average.divide(timeElapsed, RoundingMode.HALF_UP);
        //coded
        System.out.println("Cost per PricePlan "+averagedCost.multiply(pricePlan.getUnitRate()));
        return averagedCost.multiply(pricePlan.getUnitRate());
    }

    private BigDecimal calculateAverageReading(List<ElectricityReading> electricityReadings) {
    	//map reduce
        BigDecimal summedReadings = electricityReadings.stream()
                .map(ElectricityReading::getReading)
                .reduce(BigDecimal.ZERO, (reading, accumulator) -> reading.add(accumulator));

        return summedReadings.divide(BigDecimal.valueOf(electricityReadings.size()), RoundingMode.HALF_UP);
    }

    private BigDecimal calculateTimeElapsed(List<ElectricityReading> electricityReadings) {
        ElectricityReading first = electricityReadings.stream()
                .min(Comparator.comparing(ElectricityReading::getTime))
                .get();
        ElectricityReading last = electricityReadings.stream()
                .max(Comparator.comparing(ElectricityReading::getTime))
                .get();

        return BigDecimal.valueOf(Duration.between(first.getTime(), last.getTime()).getSeconds() / 3600.0);
    }

}
